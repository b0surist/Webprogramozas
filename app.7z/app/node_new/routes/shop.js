import express from 'express'
import * as controlles from '../controlles/product.js'


const router = express.Router()

router.get('/', controlles.getAllProducts)

export default router